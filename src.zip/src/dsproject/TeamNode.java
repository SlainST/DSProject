/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dsproject;

/**
 *
 * @author slainst
 */
public class TeamNode {
     Team team;
        TeamNode next;
        
        public TeamNode(Team team){
            this.team = team;
            this.next = null;
        }
   
}