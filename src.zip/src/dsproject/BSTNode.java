/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dsproject;

public class BSTNode {
    
    int data;
    BSTNode left;
    BSTNode right;
    
    public BSTNode(int value){
        this.data = value;
    }
    
}